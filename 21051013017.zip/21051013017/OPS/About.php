<!docype html>
  <!DOCTYPE html>
  <html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
    <style type="text/css">
.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #ffffcc;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  padding: 12px 16px;
  z-index: 1;
}

.dropdown:hover .dropdown-content {
  display: block;
}




    *{

      margin:0 0;
    }
  #all{background-color:#ffffcc;
    height:100vh ;
    width:auto ;}
#us{border-radius:26px ;
margin-left: 26px;
margin-top: 26px;}

#pass{border-radius:26px ;
margin-left:26px;
margin-top: 26px;}

#lg{border-radius:26px ;
margin-left:100px;
margin-top: 26px;}


    
    #link{
    height:20vh ;
    width:auto ;
  background-color:;

   }  
#log{
  background-color:;
  height: 80vh;
  width: 50%;
  float:left;

 }
 #ko{
  float:left;
  background-color:;
  height:80vh;
  width:50%;
  font-family:Times New  Roman;
 }
.map{
  margin-left:40%;
}

  </style>
</head>
<body>
  <div id="all">
  <div id="link">
    <div class="dropdown">
  <span style="font-size:30px;">Menu</span>
  <div class="dropdown-content">
  <p>
    <a href="home.php" id="hom" style="margin-left:90px; font-size:30px;">Home</a>
           <a href="image.php" id="img"style="margin-left:150px;font-size:30px;">Image</a>
          <a href="about.php" id="abt" style="margin-left:180px;font-size:30px;">About</a>
         <a href="contacts.php" id="contact" style="margin-left:250px;font-size:30px; ">Contact</a>
  </p>
  </div>
</div>
  </head>
  <body>
    <h1 align="center" style="background-color:;">LEARNING THROUGH PAST PAPER </h1>
  <div class="map">
<div>
<tr><td align="center"><a href="logout.php"><b>Back</td></b></tr><br>
<tr><td><a href="register.php" style="background-color:ORANGE;">CLICK HERE TO JOIN US</a></td></tr>
</div>
  <td  style="color:gren; align:left;">We are the one of the among of educational trainer we are helping now days scholers to preview what other lernt in past so as to increase and improve skills to young lerners  <br>
     We are suppliying all past papers through written documents as well as soft documents through our site 
     WE are supplying through the whole country  and we are dealing with all subjects based on all leavels 
     FORM ONE up FORM SIX 

     for more information contact us through:. 
  </td>
</tr>
  <br>
  <br>

</tr>
</body>
<td> 
Via  nornal calls,whatsapp,telegram 
</td>
</tr>

<tr><td><b> 
  <imag src="" height=""width="">
    <a href=""target=""></a><br>
+255657684318<br>
+255768124318<br>
+255739684318
</b>
</td></tr>

  <br>

</tr><td> <b>Via email </b><br>
mangafrank20@gmail.com<br>
mangafrank230@gmail.com</td>

 </td></tr>

<tr><td>


    <br>
  <br>
  <br><b>
  <?php 
session_start()

  ?>
  VIA SOCIAL MEDIAS<br>
<img src="../photoes/download.png"height="20px"width="20px">
    <a href="https://wa.me/message/OVYMWW6AG5GZF1"target="blank">Message</a><br>

  <img src="../photoes/download.jpg" height="20px"width="20px">

    <a href="https://www.instagram.com/contact/?invites/i=1gyi9oodxc4ky&utm_content=lz69i9q"target="blank">Instagram</a><br>

  <img src="../photoes/downl.jpg" height="20px"width="20px">
    <a href="https//tel:0657684318"target="blank">Call</a><br>

  <img src="../photoes/download1.png" height="20px"width="20px">
    <a href=""target="blank">twitter</a><br>
    <img src="../photoes/downlo.jpg" height="20px"width="20px">
    <a href="https://telegram.org/dl"target="blank">telegram</a>
  <br>
<img src="../photoes/fb.png" height="20px"width="20px">
    <a href=""target="blank">Facebook</a>
    <br>
   for more information <br>
   follow us via <br>
   www.pastp.tz<br>

</b>
</td></tr>
</table>
</div>
  </body>
  </html>