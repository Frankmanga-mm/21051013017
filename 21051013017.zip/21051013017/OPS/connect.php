<?php 
$conn=mysqli_connect("localhost:3306","root","","21051013017") or die("unable to connect");

?>